# gdoc
Sistema de gerenciamento de arquivos e processos
